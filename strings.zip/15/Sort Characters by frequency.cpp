#include <iostream>
#include <string>
#include <unordered_map>
#include <vector>
#include <algorithm>

using namespace std;

class Solution {
public:
    string frequencySort(string s) {
        // Create a frequency map
        unordered_map<char, int> freq;
        for (char c : s) {
            freq[c]++;
        }

        // Create a vector of pairs (character, frequency)
        vector<pair<char, int>> freqVec(freq.begin(), freq.end());

        // Sort the vector by frequency in descending order
        sort(freqVec.begin(), freqVec.end(), [](pair<char, int> &a, pair<char, int> &b) {
            return a.second > b.second;
        });

        // Build the result string
        string result;
        for (auto &p : freqVec) {
            result.append(p.second, p.first);
        }

        return result;
    }
};

int main() {
    Solution solution;
    string s = "Leena";
    
    string result = solution.frequencySort(s);
    cout << result << endl;

    return 0;
}

