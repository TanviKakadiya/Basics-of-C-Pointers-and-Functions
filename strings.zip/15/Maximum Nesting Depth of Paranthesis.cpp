#include <iostream>
#include <string>

using namespace std;

class Solution {
public:
    int maxDepth(string s) {
        int currentDepth = 0, maxDepth = 0;
        
        for (char c : s) {
            if (c == '(') {
                currentDepth++;
                if (currentDepth > maxDepth) {
                    maxDepth = currentDepth;
                }
            } else if (c == ')') {
                currentDepth--;
            }
        }
        
        return maxDepth;
    }
};

int main() {
    Solution solution;
    
    string s1 = "(1+(2*3)+((8)/4))+1";
    string s2 = "(1)+((2))+(((3)))+10";
    string s3 = "()(())((()()))";
    
    cout << solution.maxDepth(s1) << endl;  
    cout << solution.maxDepth(s2) << endl; 
    cout << solution.maxDepth(s3) << endl; 

    return 0;
}

