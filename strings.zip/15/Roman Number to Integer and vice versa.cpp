#include <iostream>
#include <unordered_map>
#include <string>

using namespace std;

class Solution {
public:
    int romanToInt(string s) {
        // Create a map to store Roman numeral values
        unordered_map<char, int> romanMap = {
            {'I', 1}, {'V', 5}, {'X', 10}, {'L', 50},
            {'C', 100}, {'D', 500}, {'M', 1000}
        };
        
        int total = 0;
        int n = s.length();
        
        for (int i = 0; i < n; i++) {
            // If the current numeral is less than the next one, subtract it
            if (i < n - 1 && romanMap[s[i]] < romanMap[s[i + 1]]) {
                total -= romanMap[s[i]];
            } else {
                // Otherwise, add its value
                total += romanMap[s[i]];
            }
        }
        
        return total;
    }
};

int main() {
    Solution solution;
    
    string s1 = "II";
    string s2 = "LVIII";
    string s3 = "MCMXCIV";
    
    cout << solution.romanToInt(s1) << endl;  // Output: 3
    cout << solution.romanToInt(s2) << endl;  // Output: 58
    cout << solution.romanToInt(s3) << endl;  // Output: 1994

    return 0;
}

