#include <iostream>
#include <string>

using namespace std;

string largestOddNumber(const string& num) {
    // Traverse the string from the end to the beginning
    for (int i = num.size() - 1; i >= 0; --i) {
        // Check if the current character is an odd digit
        if ((num[i] - '0') % 2 != 0) {
            // Return the substring from the beginning to the current position
            return num.substr(0, i + 1);
        }
    }
    // If no odd digit was found, return an empty string
    return "";
}

int main() {
    string num;
    cout << "Enter a number: ";
    getline(cin, num);
    
    // Remove any non-digit characters
    string cleaned_num;
    for (int i = 0; i < num.size(); ++i) {
        if (isdigit(num[i])) {
            cleaned_num += num[i];
        }
    }
    
    string result = largestOddNumber(cleaned_num);
    
    if (result.empty()) {
        cout << "There are no odd numbers in the input" << endl;
    } else {
        cout << "The largest-valued odd integer substring is: " << result << endl;
    }
    
    return 0;
}

