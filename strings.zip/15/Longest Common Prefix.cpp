#include <iostream>
#include <vector>
#include <string>

using namespace std;

string longestCommonPrefix(const vector<string>& strs) {
    if (strs.empty()) return "";

    // Initialize the prefix with the first string
    string prefix = strs[0];

    // Compare the prefix with each string in the array
    for (size_t i = 1; i < strs.size(); ++i) {
        const string& current = strs[i];
        size_t j = 0;
        // Find the common prefix between 'prefix' and 'current'
        while (j < prefix.size() && j < current.size() && prefix[j] == current[j]) {
            ++j;
        }
        // Update the prefix based on the comparison
        prefix = prefix.substr(0, j);
        // If at any point the prefix becomes empty, return it immediately
        if (prefix.empty()) return "";
    }

    return prefix;
}

int main() {
    vector<string> strs;
    string input;
    
    cout << "Enter strings separated by spaces (type 'end' to finish):" << endl;
    
    while (cin >> input && input != "end") {
        strs.push_back(input);
    }
    
    string result = longestCommonPrefix(strs);
    
    if (result.empty()) {
        cout << "There is no common prefix." << endl;
    } else {
        cout << "The longest common prefix is: " << result << endl;
    }
    
    return 0;
}

