#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

class Solution {
public:
    string reverseWords(string s) {
        // Step 1: Trim leading and trailing spaces
        int left = 0, right = s.size() - 1;
        while (left <= right && s[left] == ' ') left++;
        while (right >= left && s[right] == ' ') right--;
        
        // Step 2: Split the string into words
        vector<string> words;
        string word;
        while (left <= right) {
            char c = s[left];
            if (c != ' ') {
                word += c;
            } else if (!word.empty()) {
                words.push_back(word);
                word.clear();
            }
            left++;
        }
        // Push the last word
        if (!word.empty()) {
            words.push_back(word);
        }

        // Step 3: Reverse the list of words
        reverse(words.begin(), words.end());

        // Step 4: Join the words with a single space
        string result;
        for (int i = 0; i < words.size(); ++i) {
            result += words[i];
            if (i < words.size() - 1) {
                result += " ";
            }
        }
        
        return result;
    }
};

int main() {
    Solution solution;
    cout << solution.reverseWords("the sky is blue") << endl;        
    cout << solution.reverseWords("  hello world  ") << endl;        
    cout << solution.reverseWords("a good   example") << endl;       
    return 0;
}

