#include <iostream>
#include <string>

using namespace std;

string removeOuterParentheses(const string& s) {
    string result;
    int depth = 0;
    
    for (size_t i = 0; i < s.length(); ++i) {
        char c = s[i];
        if (c == '(') {
            if (depth > 0) {
                result += c; // Add to result if not at the outermost level
            }
            ++depth;
        } else if (c == ')') {
            --depth;
            if (depth > 0) {
                result += c; // Add to result if not at the outermost level
            }
        }
    }
    
    return result;
}

int main() {
    string s1 = "(()())(())";
    string s2 = "(()())(())(()(()))";
    string s3 = "()()";
    
    cout << "Input: " << s1 << " -> Output: " << removeOuterParentheses(s1) << endl;
    cout << "Input: " << s2 << " -> Output: " << removeOuterParentheses(s2) << endl;
    cout << "Input: " << s3 << " -> Output: " << removeOuterParentheses(s3) << endl;
    
    return 0;
}

