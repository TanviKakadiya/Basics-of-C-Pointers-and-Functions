#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <algorithm>

using namespace std;

string reverseWords(string s) {
    // Remove leading and trailing spaces
    int start = s.find_first_not_of(' ');
    int end = s.find_last_not_of(' ');
    
    if (start == string::npos) {
        return ""; // If the string is empty or only contains spaces
    }

    s = s.substr(start, end - start + 1);
    
    // Split the string into words
    istringstream iss(s);
    vector<string> words;
    string word;
    
    while (iss >> word) {
        words.push_back(word);
    }
    
    // Reverse the words
    reverse(words.begin(), words.end());
    
    // Join the words with a single space
    string result;
    for (size_t i = 0; i < words.size(); ++i) {
        result += words[i];
        if (i < words.size() - 1) {
            result += " ";
        }
    }
    
    return result;
}

int main() {
    string s1 = "the sky is blue";
    string s2 = "  hello world  ";
    string s3 = "a good   example";
    
    cout << "Input: \"" << s1 << "\" -> Output: \"" << reverseWords(s1) << "\"" << endl;
    cout << "Input: \"" << s2 << "\" -> Output: \"" << reverseWords(s2) << "\"" << endl;
    cout << "Input: \"" << s3 << "\" -> Output: \"" << reverseWords(s3) << "\"" << endl;
    
    return 0;
}

