#include <iostream>
#include <unordered_map>
#include <string>

using namespace std;

class Solution {
public:
    int countAtMostKDistinct(string& s, int K) {
        int n = s.length();
        unordered_map<char, int> charCount;
        int left = 0, right = 0;
        int count = 0, distinct = 0;
        
        while (right < n) {
            char rightChar = s[right];
            if (charCount[rightChar] == 0) {
                distinct++;
            }
            charCount[rightChar]++;
            right++;
            
            while (distinct > K) {
                char leftChar = s[left];
                charCount[leftChar]--;
                if (charCount[leftChar] == 0) {
                    distinct--;
                }
                left++;
            }
            
            count += right - left;
        }
        
        return count;
    }
    
    int substrCount(string S, int K) {
        return countAtMostKDistinct(S, K) - countAtMostKDistinct(S, K - 1);
    }
};

int main() {
    Solution solution;
    
    cout << solution.substrCount("aba", 2) << endl;        
    cout << solution.substrCount("abaacaa", 1) << endl;    
    
    return 0;
}

