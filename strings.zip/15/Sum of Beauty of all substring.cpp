#include <iostream>
#include <vector>
#include <string>
#include <algorithm>
#include <climits>

using namespace std;

class Solution {
public:
    int beautySum(string s) {
        int n = s.length();
        int totalBeauty = 0;
        
        // Iterate over all possible starting points of substrings
        for (int i = 0; i < n; ++i) {
            vector<int> freq(26, 0);
            // Expand the substring starting from i to j
            for (int j = i; j < n; ++j) {
                freq[s[j] - 'a']++;  // Update frequency of the current character
                
                int maxFreq = 0, minFreq = INT_MAX;
                for (int k = 0; k < 26; ++k) {
                    if (freq[k] > 0) {
                        maxFreq = max(maxFreq, freq[k]);
                        minFreq = min(minFreq, freq[k]);
                    }
                }
                
                totalBeauty += (maxFreq - minFreq);
            }
        }
        
        return totalBeauty;
    }
};

int main() {
    Solution solution;
    
    cout << solution.beautySum("aabcb") << endl;    // Output: 5
    cout << solution.beautySum("aabcbaa") << endl;  // Output: 17
    
    return 0;
}

