#include <iostream>
#include <unordered_map>
#include <string>

using namespace std;

bool isIsomorphic(const string& s, const string& t) {
    if (s.length() != t.length()) return false;

    unordered_map<char, char> mapS;  // Mapping from s to t
    unordered_map<char, char> mapT;  // Mapping from t to s

    for (size_t i = 0; i < s.length(); ++i) {
        char charS = s[i];
        char charT = t[i];
        
        // Check the mapping from s to t
        if (mapS.find(charS) != mapS.end()) {
            if (mapS[charS] != charT) {
                return false;
            }
        } else {
            mapS[charS] = charT;
        }

        // Check the mapping from t to s
        if (mapT.find(charT) != mapT.end()) {
            if (mapT[charT] != charS) {
                return false;
            }
        } else {
            mapT[charT] = charS;
        }
    }

    return true;
}

int main() {
    string s, t;
    
    cout << "Enter first string: ";
    cin >> s;
    
    cout << "Enter second string: ";
    cin >> t;
    
    if (isIsomorphic(s, t)) {
        cout << "The strings are isomorphic." << endl;
    } else {
        cout << "The strings are not isomorphic." << endl;
    }
    
    return 0;
}

